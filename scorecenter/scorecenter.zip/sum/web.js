
var mongoUri = process.env.MONGOHQ_URL || 'mongodb://user:pass@linus.mongohq.com:10009/app14612479'; 
var collection = ['scores'];
var db =require('mongojs').connect(mongoUri,collection);

var express = require('express');
var app = express();
app.use(express.bodyParser());

app.use("/styles", express.static(__dirname + '/styles'));
app.set('title', 'Scorecenter');


var displayhtml;
var sitehtml;
var scores_array =[];



app.get('/', function(request, response) {
	var responsestring =[];
	db.scores.find(function(err, games){
		if(err || !games){console.log(err);}
		else{ scores_array = games.map(function(gamefound){
				responsestring[0] = gamefound.game_title;
				responsestring[1] = gamefound.username;
				responsestring[2] = gamefound.score;
				responsestring[3] = gamefound.created_at;
				return build_scores(responsestring);
				});
			display(scores_array);
			response.send(sitehtml);
		}
	});
	
});	

function build_scores(input_array){
	//scores_array.push({);
	//console.log(scores_array);
	return {game_title: input_array[0],username:input_array[1],score:input_array[2],created_at:input_array[3]};
}

function encodeHTML(s) {
    return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/"/g, '&quot;');
    //sanitation code from:
    //http://stackoverflow.com/questions/2794137/sanitizing-user-input-before-adding-it-to-the-dom-in-javascript
}


var port = process.env.PORT || 5000;
app.listen(port, function() {
  console.log("Listening on " + port);
});


app.all('/', function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "X-Requested-With");
  next();
 });


app.post("/submit.json",function(request,response){
	var user = encodeHTML(request.body.username);
	var score_val = encodeHTML(request.body.score);
	var game = encodeHTML(request.body.game_title);
	var time = new Date;
	db.scores.insert({
		username:user,
		created_at:time,
		game_title:game,
		score:score_val

	});
	response.send("Submition Recieved");
});



app.get('/usersearch',function(req,res){
	var searchhtml = '<form name="search" action="/search_results" method="post">Username: <input type="text" name="username">' +
		'<input value="submit" type="Submit"></form>';
	res.send(searchhtml);
});


app.post('/search_results', function(req,res){
	var search_name = encodeHTML(req.body.username);
	var name_array = [];
	var scores_array = [];
	var responsestring = [];
	db.scores.find(function(err, games){
	if(err || !games){console.log(err);}
	else{ scores_array = games.map(function(gamefound){
			responsestring[0] = gamefound.game_title;
			responsestring[1] = gamefound.username;
			responsestring[2] = gamefound.score;
			responsestring[3] = gamefound.created_at;
			return build_scores(responsestring);
			});
		sort_scores(scores_array);
		for(i in scores_array){
			if(scores_array[i].username == search_name){
				name_array.push(scores_array[i]);
			}
		}
		display(name_array);
		res.send(sitehtml);
		}
	});
});



app.get('/highscores.json',function(req, res) {
	var top_ten = [];
	var scores_array = [];
	var responsestring = [];
	var game = req.query.game_title;
	db.scores.find(function(err, games){
	if(err || !games){console.log(err);}
	else{ scores_array = games.map(function(gamefound){
			responsestring[0] = gamefound.game_title;
			responsestring[1] = gamefound.username;
			responsestring[2] = gamefound.score;
			responsestring[3] = gamefound.created_at;
			return build_scores(responsestring);
			});
		sort_scores(scores_array);
		var j = 0;
		for(i in scores_array){
			if(j == 9){break};
			if(scores_array[i].game_title == game){
				top_ten[j] = scores_array[i];
				j++;
			}
		}
		res.set('content-type','text/json');
		res.send(top_ten);
	}
	});	
});



function sort_scores(list_scores){
	list_scores.sort(function(a,b){
			return parseInt(b.score) - parseInt(a.score);
	});
}

function display(list_scores){
	var table;
	sitehtml = '<html><head>' +
	'<link href="styles/style.css" rel="stylesheet"/>' +
	'<title>Scorecenter</title></head><body>';
	table = '<table border="1"><tr><td>Game</td><td>Username</td><td>Score</td><td>Time</td></tr>';
	sort_scores(list_scores);
	for(i in list_scores){
		table += '<tr>' +
		'<td>' + list_scores[i].game_title + '</td>'+
		'<td>' + list_scores[i].username + '</td>'+
		'<td>' + list_scores[i].score + '</td>'+
		'<td>' + list_scores[i].created_at + '</td>'+
		'</tr>';
	}
	table + '</table>'
	sitehtml += table + '</body></html>';
	return table;
}

