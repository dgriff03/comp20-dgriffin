This assignment has taken me around 20hrs

I got help on this assignment from Brett Fischler and Eric Mariasis

This site lacks any 404 or error pages. There is also no navigation within the page which would be an issue.
Everything asked for is implemented
